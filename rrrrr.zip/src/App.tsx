import { useState } from 'react'

function FiberBackground() {
  return (
    <svg className="absolute inset-0 w-full h-full" xmlns="http://www.w3.org/2000/svg">
      <defs>
        <radialGradient id="glow1" cx="30%" cy="40%" r="50%">
          <stop offset="0%" stopColor="#3b5bfc" stopOpacity="0.18" />
          <stop offset="100%" stopColor="#3b5bfc" stopOpacity="0" />
        </radialGradient>
        <radialGradient id="glow2" cx="75%" cy="65%" r="45%">
          <stop offset="0%" stopColor="#7c3aed" stopOpacity="0.12" />
          <stop offset="100%" stopColor="#7c3aed" stopOpacity="0" />
        </radialGradient>
        <filter id="blur2">
          <feGaussianBlur stdDeviation="2" />
        </filter>
      </defs>

      {/* Ambient glow blobs */}
      <rect width="100%" height="100%" fill="url(#glow1)" />
      <rect width="100%" height="100%" fill="url(#glow2)" />

      {/* Grid lines */}
      {Array.from({ length: 20 }).map((_, i) => (
        <line
          key={`v${i}`}
          x1={`${i * 5.26}%`} y1="0" x2={`${i * 5.26}%`} y2="100%"
          stroke="rgba(100,130,255,0.04)" strokeWidth="1"
        />
      ))}
      {Array.from({ length: 20 }).map((_, i) => (
        <line
          key={`h${i}`}
          x1="0" y1={`${i * 5.26}%`} x2="100%" y2={`${i * 5.26}%`}
          stroke="rgba(100,130,255,0.04)" strokeWidth="1"
        />
      ))}

      {/* Network nodes */}
      {[
        [12, 18], [28, 42], [18, 68], [42, 15], [55, 55],
        [70, 25], [85, 48], [75, 75], [35, 82], [62, 88],
      ].map(([cx, cy], i) => (
        <circle
          key={i}
          cx={`${cx}%`} cy={`${cy}%`} r="3"
          fill="#3b5bfc"
          className="network-node"
          style={{ animationDelay: `${i * 0.4}s` }}
        />
      ))}

      {/* Network edges */}
      {[
        ['12%,18%', '28%,42%'],
        ['28%,42%', '18%,68%'],
        ['28%,42%', '42%,15%'],
        ['42%,15%', '70%,25%'],
        ['55%,55%', '70%,25%'],
        ['55%,55%', '75%,75%'],
        ['70%,25%', '85%,48%'],
        ['85%,48%', '75%,75%'],
        ['35%,82%', '18%,68%'],
        ['62%,88%', '75%,75%'],
        ['55%,55%', '35%,82%'],
      ].map(([a, b], i) => {
        const [x1, y1] = a.split(',')
        const [x2, y2] = b.split(',')
        return (
          <line
            key={i}
            x1={x1} y1={y1} x2={x2} y2={y2}
            stroke="rgba(59,91,252,0.18)" strokeWidth="1"
            strokeDasharray="4 3"
          />
        )
      })}
    </svg>
  )
}

function EyeIcon({ show }: { show: boolean }) {
  return show ? (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
    </svg>
  ) : (
    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" />
    </svg>
  )
}

export default function App() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleSignIn = (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    if (!email || !password) { setError('Please fill in all fields.'); return }
    setLoading(true)
    setTimeout(() => { setLoading(false) }, 1800)
  }

  const handleDemo = () => {
    setEmail('admin@siraigonj.net')
    setPassword('demo1234')
    setError('')
  }

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-[#070c1b]">
      <FiberBackground />

      {/* Top brand strip */}
      <div
        className="absolute top-0 inset-x-0 h-0.5 animate-fade-up"
        style={{
          background: 'linear-gradient(90deg, transparent, #3b5bfc 40%, #a78bfa 60%, transparent)',
        }}
      />

      {/* Login card */}
      <div
        className="glass-card relative z-10 w-full mx-4 rounded-3xl p-8 sm:p-10 animate-fade-up"
        style={{ maxWidth: 420, animationDelay: '0.1s' }}
      >
        {/* Logo icon */}
        <div className="flex justify-center mb-7">
          <div className="relative">
            {/* Spinning ring */}
            <svg className="icon-ring absolute inset-0 w-full h-full" viewBox="0 0 80 80">
              <circle
                cx="40" cy="40" r="36"
                fill="none"
                stroke="url(#ringGrad)"
                strokeWidth="1.5"
                strokeDasharray="56 170"
                strokeLinecap="round"
              />
              <defs>
                <linearGradient id="ringGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#3b5bfc" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#a78bfa" stopOpacity="0.2" />
                </linearGradient>
              </defs>
            </svg>
            <div
              className="w-20 h-20 rounded-2xl flex items-center justify-center"
              style={{
                background: 'linear-gradient(135deg, #3b5bfc 0%, #5b7dff 100%)',
                boxShadow: '0 8px 32px rgba(59,91,252,0.55)',
              }}
            >
              <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.2}
                  d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
          </div>
        </div>

        {/* Title */}
        <div className="text-center mb-8">
          <h1
            className="font-outfit font-bold text-3xl sm:text-4xl leading-tight mb-2"
            style={{ color: '#f0f4ff' }}
          >
            Siraigonj Fiber
            <br />Network
          </h1>
          <p className="text-sm font-medium" style={{ color: 'rgba(160,185,230,0.65)' }}>
            Fiber Core Information Management System
          </p>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-3 mb-7">
          <div className="flex-1 h-px" style={{ background: 'rgba(255,255,255,0.08)' }} />
          <span className="text-xs font-outfit font-medium" style={{ color: 'rgba(140,165,220,0.5)' }}>
            SIGN IN TO CONTINUE
          </span>
          <div className="flex-1 h-px" style={{ background: 'rgba(255,255,255,0.08)' }} />
        </div>

        <form onSubmit={handleSignIn} className="space-y-4">
          {/* Email */}
          <div>
            <label className="block text-xs font-semibold mb-1.5 font-outfit tracking-wide" style={{ color: 'rgba(180,200,240,0.8)' }}>
              EMAIL ADDRESS
            </label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2" style={{ color: 'rgba(140,165,220,0.5)' }}>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
              </span>
              <input
                type="email"
                className="input-field w-full rounded-xl py-3.5 pl-11 pr-4 text-sm"
                placeholder="admin@siraigonj.net"
                value={email}
                onChange={e => setEmail(e.target.value)}
              />
            </div>
          </div>

          {/* Password */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold font-outfit tracking-wide" style={{ color: 'rgba(180,200,240,0.8)' }}>
                PASSWORD
              </label>
              <button type="button" className="text-xs font-medium hover:underline" style={{ color: '#5b7dff' }}>
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2" style={{ color: 'rgba(140,165,220,0.5)' }}>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
              </span>
              <input
                type={showPass ? 'text' : 'password'}
                className="input-field w-full rounded-xl py-3.5 pl-11 pr-12 text-sm"
                placeholder="Enter your password"
                value={password}
                onChange={e => setPassword(e.target.value)}
              />
              <button
                type="button"
                onClick={() => setShowPass(v => !v)}
                className="absolute right-4 top-1/2 -translate-y-1/2 transition-colors"
                style={{ color: 'rgba(140,165,220,0.5)' }}
              >
                <EyeIcon show={showPass} />
              </button>
            </div>
          </div>

          {/* Error */}
          {error && (
            <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs" style={{ background: 'rgba(239,68,68,0.12)', border: '1px solid rgba(239,68,68,0.25)', color: '#fca5a5' }}>
              <svg className="w-3.5 h-3.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
              </svg>
              {error}
            </div>
          )}

          {/* Sign In */}
          <button
            type="submit"
            disabled={loading}
            className="btn-primary w-full py-3.5 rounded-xl font-outfit font-semibold text-white text-base tracking-wide mt-2 disabled:opacity-60 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {loading ? (
              <>
                <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Signing in…
              </>
            ) : (
              <>
                Sign In
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </>
            )}
          </button>

          {/* Demo */}
          <button
            type="button"
            onClick={handleDemo}
            className="btn-secondary w-full py-3.5 rounded-xl font-outfit font-medium text-sm tracking-wide flex items-center justify-center gap-2"
            style={{ color: 'rgba(180,200,240,0.75)' }}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
            </svg>
            Use Demo Account
          </button>
        </form>

        {/* Stats row */}
        <div className="mt-8 pt-6 grid grid-cols-3 gap-2" style={{ borderTop: '1px solid rgba(255,255,255,0.07)' }}>
          {[
            { label: 'Fiber Links', value: '1,240+' },
            { label: 'Coverage KM', value: '842 km' },
            { label: 'Active Cores', value: '98.6%' },
          ].map(({ label, value }) => (
            <div key={label} className="text-center">
              <p className="font-outfit font-bold text-base" style={{ color: '#5b7dff' }}>{value}</p>
              <p className="text-xs mt-0.5" style={{ color: 'rgba(140,165,220,0.5)' }}>{label}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Footer */}
      <p
        className="relative z-10 mt-6 text-xs animate-fade-up"
        style={{ color: 'rgba(100,130,180,0.45)', animationDelay: '0.4s' }}
      >
        © 2026 Siraigonj Fiber Network · Secure &amp; Encrypted
      </p>
    </div>
  )
}
